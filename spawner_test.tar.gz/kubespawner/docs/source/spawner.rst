==============
   Spawners
==============


Module: :mod:`kubespawner.spawner`
----------------------------------

.. automodule:: kubespawner.spawner

:class:`KubeSpawner`
--------------------

.. autoconfigurable:: KubeSpawner
