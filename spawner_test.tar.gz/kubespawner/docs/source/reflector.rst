=========
Reflector
=========

Module: :mod:`kubespawner.reflector`
------------------------------------

.. automodule:: kubespawner.reflector

.. autoclass:: kubespawner.reflector.NamespacedResourceReflector