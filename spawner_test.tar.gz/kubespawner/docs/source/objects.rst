=======
Objects
=======

Module: :mod:`kubespawner.objects`
----------------------------------

.. automodule:: kubespawner.objects

.. currentmodule:: kubespawner.objects

.. autofunction:: make_pod

.. autofunction:: make_pvc
